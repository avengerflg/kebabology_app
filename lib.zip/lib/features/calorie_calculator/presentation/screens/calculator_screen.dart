// lib/features/calorie_calculator/presentation/screens/calculator_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/calculator_provider.dart';
import '../widgets/component_selector.dart';
import '../widgets/weight_slider.dart';
import '../widgets/nutrition_display.dart';
import '../../../../core/constants/app_constants.dart';
import '../../data/models/kebab_component.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen>
    with TickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
          CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
        );

    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  void _scrollToNutrition() {
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          'Kebab Calorie Calculator',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w800,
            color: Colors.white,
            letterSpacing: -0.5,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppConstants.accentColor,
                AppConstants.accentColor.withOpacity(0.9),
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: AppConstants.accentColor.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 5),
              ),
            ],
          ),
        ),
        leading: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios_rounded,
              color: Colors.white,
              size: 20,
            ),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        actions: [
          Consumer<CalculatorProvider>(
            builder: (context, provider, child) {
              if (!provider.hasSelections) return const SizedBox.shrink();

              return Container(
                margin: const EdgeInsets.only(right: 12, top: 8, bottom: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: IconButton(
                  icon: const Icon(
                    Icons.refresh_rounded,
                    color: Colors.white,
                    size: 22,
                  ),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (dialogContext) =>
                          _buildClearDialog(dialogContext, provider),
                    );
                  },
                ),
              );
            },
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: _slideAnimation,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  AppConstants.accentColor.withOpacity(0.08),
                  Colors.grey.shade50,
                  Colors.white,
                ],
                stops: const [0.0, 0.4, 1.0],
              ),
            ),
            child: Consumer<CalculatorProvider>(
              builder: (context, provider, child) {
                return CustomScrollView(
                  controller: _scrollController,
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    // Header space for app bar
                    SliverToBoxAdapter(
                      child: SizedBox(
                        height:
                            MediaQuery.of(context).padding.top +
                            kToolbarHeight +
                            10,
                      ),
                    ),

                    // Welcome Hero Section
                    SliverToBoxAdapter(
                      child: Container(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white,
                                Colors.grey.shade50,
                                Colors.white,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: AppConstants.accentColor.withOpacity(
                                  0.1,
                                ),
                                blurRadius: 30,
                                offset: const Offset(0, 10),
                                spreadRadius: -5,
                              ),
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 20,
                                offset: const Offset(0, 5),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      AppConstants.accentColor.withOpacity(0.1),
                                      AppConstants.accentColor.withOpacity(
                                        0.05,
                                      ),
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Image.asset(
                                    'assets/images/logo.jpeg',
                                    width: 36,
                                    height: 36,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'Maybe she\'s born with it.\nMaybe it\'s Kebabaline',
                                style: theme.textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.w800,
                                  color: Colors.black87,
                                  height: 1.2,
                                  letterSpacing: -0.5,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: AppConstants.accentColor.withOpacity(
                                    0.1,
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  'Let the Kebabs Begin',
                                  style: theme.textTheme.bodyLarge?.copyWith(
                                    color: AppConstants.accentColor,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // Component Selectors
                    SliverPadding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      sliver: SliverList(
                        delegate: SliverChildListDelegate([
                          const SizedBox(height: 12),
                          _buildSectionCard(
                            child: ComponentSelector(
                              type: ComponentType.bread,
                              components: provider.breadOptions,
                              selected: provider.selectedBread,
                              onSelectionChanged: (breadId) {
                                provider.selectBread(breadId);
                              },
                              allowMultiple: false,
                              showCalories: false, // Add this parameter
                            ),
                          ),
                          const SizedBox(height: 12),

                          _buildSectionCard(
                            child: ComponentSelector(
                              type: ComponentType.meat,
                              components: provider.meatOptions,
                              selected: provider.selectedMeats,
                              onSelectionChanged: (meatId) {
                                provider.toggleMeat(meatId);
                              },
                              allowMultiple: true,
                              maxSelections: 2,
                              showCalories: false, // Add this parameter
                              errorMessage:
                                  provider.selectedMeats.isEmpty &&
                                      provider.hasSelections
                                  ? 'Select at least one meat'
                                  : provider.selectedMeats.length > 2
                                  ? 'Maximum 2 meats allowed'
                                  : null,
                            ),
                          ),
                          const SizedBox(height: 12),

                          _buildSectionCard(
                            child: ComponentSelector(
                              type: ComponentType.salad,
                              components: provider.saladOptions,
                              selected: provider.selectedSalads,
                              onSelectionChanged: (saladId) {
                                provider.toggleSalad(saladId);
                              },
                              allowMultiple: true,
                              maxSelections: 5,
                              showCalories: false, // Add this parameter
                              errorMessage: provider.selectedSalads.length > 5
                                  ? 'Maximum 5 salads allowed'
                                  : null,
                            ),
                          ),
                          const SizedBox(height: 12),

                          _buildSectionCard(
                            child: ComponentSelector(
                              type: ComponentType.sauce,
                              components: provider.sauceOptions,
                              selected: provider.selectedSauces,
                              onSelectionChanged: (sauceId) {
                                provider.toggleSauce(sauceId);
                              },
                              allowMultiple: true,
                              maxSelections: AppConstants.maxSauces,
                              showCalories: false, // Add this parameter
                              errorMessage:
                                  provider.selectedSauces.length >
                                      AppConstants.maxSauces
                                  ? 'Maximum ${AppConstants.maxSauces} sauces allowed'
                                  : null,
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Weight Slider
                          _buildSectionCard(
                            child: WeightSlider(
                              weight: provider.kebabWeight,
                              onChanged: (weight) {
                                provider.setWeight(weight);
                              },
                            ),
                          ),
                          const SizedBox(height: 20),

                          // Calculate Button
                          if (provider.hasSelections) ...[
                            Container(
                              margin: const EdgeInsets.symmetric(horizontal: 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow:
                                    provider.isValidKebab &&
                                        provider.selectedBread != null
                                    ? [
                                        BoxShadow(
                                          color: AppConstants.accentColor
                                              .withOpacity(0.4),
                                          blurRadius: 20,
                                          offset: const Offset(0, 10),
                                          spreadRadius: -2,
                                        ),
                                      ]
                                    : null,
                              ),
                              child: Container(
                                width: double.infinity,
                                height: 56,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors:
                                        provider.isValidKebab &&
                                            provider.selectedBread != null
                                        ? [
                                            AppConstants.accentColor,
                                            AppConstants.accentColor
                                                .withOpacity(0.8),
                                          ]
                                        : [
                                            Colors.grey.shade300,
                                            Colors.grey.shade400,
                                          ],
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(20),
                                    onTap:
                                        provider.isValidKebab &&
                                            provider.selectedBread != null
                                        ? _scrollToNutrition
                                        : null,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const Icon(
                                          Icons.analytics_rounded,
                                          color: Colors.white,
                                          size: 24,
                                        ),
                                        const SizedBox(width: 12),
                                        Text(
                                          'View Nutrition Info',
                                          style: theme.textTheme.titleMedium
                                              ?.copyWith(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w700,
                                                letterSpacing: 0.5,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                          ],

                          // Nutrition Display
                          if (provider.hasSelections)
                            Container(
                              margin: const EdgeInsets.symmetric(horizontal: 8),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [Colors.white, Colors.grey.shade50],
                                ),
                                borderRadius: BorderRadius.circular(24),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.08),
                                    blurRadius: 30,
                                    offset: const Offset(0, 15),
                                    spreadRadius: -5,
                                  ),
                                  BoxShadow(
                                    color: AppConstants.accentColor.withOpacity(
                                      0.1,
                                    ),
                                    blurRadius: 20,
                                    offset: const Offset(0, 5),
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(24),
                                child: NutritionDisplay(
                                  totalNutrition: provider.totalNutrition,
                                  nutritionByType: provider.nutritionByType,
                                  isValid:
                                      provider.isValidKebab &&
                                      provider.selectedBread != null,
                                  errorMessage:
                                      provider.validationError ??
                                      (provider.selectedBread == null
                                          ? 'Please select a bread type'
                                          : null),
                                ),
                              ),
                            ),

                          const SizedBox(height: 30),
                        ]),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required Widget child,
    String? title,
    IconData? icon,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.white, Colors.grey.shade50],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
            spreadRadius: -3,
          ),
          BoxShadow(
            color: AppConstants.accentColor.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null && icon != null)
            Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppConstants.accentColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      icon,
                      size: 20,
                      color: AppConstants.accentColor,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Colors.black87,
                      letterSpacing: -0.2,
                    ),
                  ),
                ],
              ),
            ),
          child,
        ],
      ),
    );
  }

  Widget _buildClearDialog(
    BuildContext dialogContext,
    CalculatorProvider provider,
  ) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      backgroundColor: Colors.white,
      elevation: 30,
      shadowColor: Colors.black.withOpacity(0.3),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.orange.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.warning_amber_rounded,
              color: Colors.orange,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          const Text(
            'Clear Selections?',
            style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: -0.3),
          ),
        ],
      ),
      content: Text(
        'This will reset all your selections and start over. Are you sure?',
        style: TextStyle(
          height: 1.5,
          color: Colors.grey.shade700,
          fontSize: 16,
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dialogContext),
          style: TextButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'Cancel',
            style: TextStyle(
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                AppConstants.accentColor,
                AppConstants.accentColor.withOpacity(0.8),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: AppConstants.accentColor.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: TextButton(
            onPressed: () {
              provider.clearSelections();
              Navigator.pop(dialogContext);
            },
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              'Clear All',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
