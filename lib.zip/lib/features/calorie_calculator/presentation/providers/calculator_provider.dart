// lib/features/calorie_calculator/presentation/providers/calculator_provider.dart

import 'package:flutter/foundation.dart';
import '../../data/models/kebab_component.dart';
import '../../data/repositories/kebab_repository.dart';
import '../../data/repositories/nutrition_repository.dart';
import '../../../../core/constants/app_constants.dart';

class CalculatorProvider extends ChangeNotifier {
  final KebabRepository _kebabRepository = KebabRepository();
  final NutritionRepository _nutritionRepository = NutritionRepository();

  // Selected components
  String? _selectedBread;
  final List<String> _selectedMeats = [];
  final List<String> _selectedSalads = [];
  final List<String> _selectedSauces = [];
  double _kebabWeight = AppConstants.standardKebabWeight;

  // Getters
  String? get selectedBread => _selectedBread;
  List<String> get selectedMeats => List.unmodifiable(_selectedMeats);
  List<String> get selectedSalads => List.unmodifiable(_selectedSalads);
  List<String> get selectedSauces => List.unmodifiable(_selectedSauces);
  double get kebabWeight => _kebabWeight;

  // Get all components
  Map<ComponentType, List<KebabComponent>> get allComponents =>
      _kebabRepository.getAllComponents();

  // Get specific component lists
  List<KebabComponent> get breadOptions => _kebabRepository.getBreadOptions();
  List<KebabComponent> get meatOptions => _kebabRepository.getMeatOptions();
  List<KebabComponent> get saladOptions => _kebabRepository.getSaladOptions();
  List<KebabComponent> get sauceOptions => _kebabRepository.getSauceOptions();

  // Get all components as a flat list
  List<KebabComponent> get _allComponentsList {
    return [...breadOptions, ...meatOptions, ...saladOptions, ...sauceOptions];
  }

  // Selection methods
  void selectBread(String? breadId) {
    _selectedBread = breadId;
    notifyListeners();
  }

  void toggleMeat(String meatId) {
    if (_selectedMeats.contains(meatId)) {
      _selectedMeats.remove(meatId);
    } else {
      // Check if we can add more meats (max 2)
      if (_selectedMeats.length < 2) {
        _selectedMeats.add(meatId);
      }
    }
    notifyListeners();
  }

  void toggleSalad(String saladId) {
    if (_selectedSalads.contains(saladId)) {
      _selectedSalads.remove(saladId);
    } else {
      // Check if we can add more salads (max 5)
      if (_selectedSalads.length < 5) {
        _selectedSalads.add(saladId);
      }
    }
    notifyListeners();
  }

  void toggleSauce(String sauceId) {
    if (_selectedSauces.contains(sauceId)) {
      _selectedSauces.remove(sauceId);
    } else {
      // Check if we can add more sauces
      if (_selectedSauces.length < AppConstants.maxSauces) {
        _selectedSauces.add(sauceId);
      }
    }
    notifyListeners();
  }

  void setWeight(double weight) {
    _kebabWeight = weight;
    notifyListeners();
  }

  // Validation
  bool get isValidKebab => _kebabRepository.isValidKebab(
    selectedMeats: _selectedMeats,
    selectedSalads: _selectedSalads,
    selectedSauces: _selectedSauces,
  );

  String? get validationError => _kebabRepository.getValidationError(
    selectedMeats: _selectedMeats,
    selectedSalads: _selectedSalads,
    selectedSauces: _selectedSauces,
  );

  // Nutrition calculations
  Map<String, double> get totalNutrition {
    if (!isValidKebab || _selectedBread == null) {
      return _nutritionRepository.initializeNutritionMap();
    }

    return _nutritionRepository.calculateTotalNutrition(
      selectedBread: _selectedBread,
      selectedMeats: _selectedMeats,
      selectedSalads: _selectedSalads,
      selectedSauces: _selectedSauces,
      kebabWeight: _kebabWeight,
      allComponents: _allComponentsList,
    );
  }

  Map<ComponentType, Map<String, double>> get nutritionByType {
    if (!isValidKebab || _selectedBread == null) {
      return {
        ComponentType.bread: _nutritionRepository.initializeNutritionMap(),
        ComponentType.meat: _nutritionRepository.initializeNutritionMap(),
        ComponentType.salad: _nutritionRepository.initializeNutritionMap(),
        ComponentType.sauce: _nutritionRepository.initializeNutritionMap(),
      };
    }

    return _nutritionRepository.calculateNutritionByType(
      selectedBread: _selectedBread,
      selectedMeats: _selectedMeats,
      selectedSalads: _selectedSalads,
      selectedSauces: _selectedSauces,
      kebabWeight: _kebabWeight,
      allComponents: _allComponentsList,
    );
  }

  // Helper methods
  bool get hasSelections =>
      _selectedBread != null ||
      _selectedMeats.isNotEmpty ||
      _selectedSalads.isNotEmpty ||
      _selectedSauces.isNotEmpty;

  void clearSelections() {
    _selectedBread = null;
    _selectedMeats.clear();
    _selectedSalads.clear();
    _selectedSauces.clear();
    _kebabWeight = AppConstants.standardKebabWeight;
    notifyListeners();
  }

  // Get component by ID
  KebabComponent? getComponentById(String id) {
    return _kebabRepository.getComponentById(id);
  }

  // Format nutrition value for display
  String formatNutritionValue(double value, String nutrient) {
    return _nutritionRepository.formatNutritionValue(value, nutrient);
  }
}
