// lib/features/calorie_calculator/presentation/widgets/nutrition_display.dart

import 'package:flutter/material.dart';
import '../../data/models/kebab_component.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/utils/calculations.dart';

class NutritionDisplay extends StatelessWidget {
  final Map<String, double> totalNutrition;
  final Map<ComponentType, Map<String, double>> nutritionByType;
  final bool isValid;
  final String? errorMessage;

  const NutritionDisplay({
    super.key,
    required this.totalNutrition,
    required this.nutritionByType,
    required this.isValid,
    this.errorMessage,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (!isValid && errorMessage != null) {
      return _buildErrorDisplay(context, theme);
    }

    final calories = totalNutrition['calories'] ?? 0;
    final protein = totalNutrition['protein'] ?? 0;
    final carbs = totalNutrition['carbohydrates'] ?? 0;

    return Column(
      children: [
        _buildMainNutritionCard(context, theme, calories, protein, carbs),
        const SizedBox(height: 16),
        _buildComponentBreakdown(context, theme),
        const SizedBox(height: 16),
        _buildDailyValueCard(context, theme),
      ],
    );
  }

  Widget _buildErrorDisplay(BuildContext context, ThemeData theme) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppConstants.accentColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppConstants.accentColor.withOpacity(0.3),
          width: 1.5,
        ),
      ),
      child: Column(
        children: [
          const Icon(Icons.error_outline, size: 48, color: AppConstants.accentColor),
          const SizedBox(height: 16),
          Text(
            errorMessage!,
            style: theme.textTheme.titleMedium?.copyWith(
              color: AppConstants.accentColor,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildMainNutritionCard(
    BuildContext context,
    ThemeData theme,
    double calories,
    double protein,
    double carbs,
  ) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppConstants.accentColor, AppConstants.secondaryAccent],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppConstants.accentColor.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: [Colors.white.withOpacity(0.1), Colors.transparent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            Text(
              'Total Nutrition',
              style: theme.textTheme.titleLarge?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildNutritionItem(
                  theme,
                  'Calories',
                  calories.round().toString(),
                  'kcal',
                  Icons.local_fire_department,
                  Colors.orange,
                ),
                _buildNutritionItem(
                  theme,
                  'Protein',
                  protein.round().toString(),
                  'g',
                  Icons.fitness_center,
                  Colors.blue,
                ),
                _buildNutritionItem(
                  theme,
                  'Carbs',
                  carbs.round().toString(),
                  'g',
                  Icons.grain,
                  Colors.amber,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNutritionItem(
    ThemeData theme,
    String label,
    String value,
    String unit,
    IconData icon,
    Color iconColor,
  ) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: iconColor, size: 24),
        ),
        const SizedBox(height: 8),
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(
              value,
              style: theme.textTheme.headlineSmall?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(width: 2),
            Text(
              unit,
              style: theme.textTheme.bodySmall?.copyWith(
                color: Colors.white.withOpacity(0.8),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: theme.textTheme.labelMedium?.copyWith(
            color: Colors.white.withOpacity(0.9),
          ),
        ),
      ],
    );
  }

  Widget _buildComponentBreakdown(BuildContext context, ThemeData theme) {
    final componentCalories = <String, double>{
      'bread': nutritionByType[ComponentType.bread]?['calories'] ?? 0,
      'meat': nutritionByType[ComponentType.meat]?['calories'] ?? 0,
      'salad': nutritionByType[ComponentType.salad]?['calories'] ?? 0,
      'sauce': nutritionByType[ComponentType.sauce]?['calories'] ?? 0,
    };

    final totalCalories = totalNutrition['calories'] ?? 0;
    final percentages = Calculations.calculateComponentPercentages(
      componentCalories,
      totalCalories,
    );

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppConstants.cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppConstants.borderColor.withOpacity(0.5),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 20,
                decoration: BoxDecoration(
                  color: AppConstants.secondaryAccent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Calorie Breakdown',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Based on fixed percentage allocations',
            style: theme.textTheme.bodySmall?.copyWith(
              color: AppConstants.secondaryTextColor,
              fontStyle: FontStyle.italic,
            ),
          ),
          const SizedBox(height: 16),
          ...ComponentType.values.map((type) {
            final calories = componentCalories[type.name] ?? 0;
            final percentage = percentages[type.name] ?? 0;

            return _buildBreakdownItem(
              context,
              theme,
              type,
              calories,
              percentage,
            );
          }),
        ],
      ),
    );
  }

  Widget _buildBreakdownItem(
    BuildContext context,
    ThemeData theme,
    ComponentType type,
    double calories,
    double percentage,
  ) {
    final color = _getComponentColor(type);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(type.displayName, style: theme.textTheme.bodyMedium),
                ],
              ),
              Row(
                children: [
                  Text(
                    '${calories.round()} cal',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      Calculations.formatPercentage(percentage),
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: color,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 4),
          LinearProgressIndicator(
            value: percentage / 100,
            backgroundColor: color.withOpacity(0.1),
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 6,
          ),
        ],
      ),
    );
  }

  Color _getComponentColor(ComponentType type) {
    switch (type) {
      case ComponentType.bread:
        return AppConstants.goldAccent;
      case ComponentType.meat:
        return AppConstants.accentColor;
      case ComponentType.salad:
        return Colors.green;
      case ComponentType.sauce:
        return AppConstants.secondaryAccent;
    }
  }

  Widget _buildDailyValueCard(BuildContext context, ThemeData theme) {
    final dailyValues = Calculations.calculateDailyValues(totalNutrition);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppConstants.surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppConstants.borderColor.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.info_outline,
                size: 20,
                color: AppConstants.secondaryTextColor,
              ),
              const SizedBox(width: 8),
              Text(
                'Daily Value (%)',
                style: theme.textTheme.labelLarge?.copyWith(
                  color: AppConstants.secondaryTextColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildDailyValueItem(
                theme,
                'Calories',
                dailyValues['calories'] ?? 0,
              ),
              _buildDailyValueItem(
                theme,
                'Protein',
                dailyValues['protein'] ?? 0,
              ),
              _buildDailyValueItem(
                theme,
                'Carbs',
                dailyValues['carbohydrates'] ?? 0,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '*Based on a 2000 calorie diet',
            style: theme.textTheme.labelSmall?.copyWith(
              color: AppConstants.secondaryTextColor.withOpacity(0.7),
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDailyValueItem(
    ThemeData theme,
    String label,
    double percentage,
  ) {
    final colorType = Calculations.getDailyValueColor(percentage);
    final color = colorType == 'low'
        ? Colors.green
        : colorType == 'moderate'
        ? Colors.orange
        : Colors.red;

    return Column(
      children: [
        Text(
          '${percentage.round()}%',
          style: theme.textTheme.titleMedium?.copyWith(
            color: color,
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          label,
          style: theme.textTheme.labelSmall?.copyWith(
            color: AppConstants.secondaryTextColor,
          ),
        ),
      ],
    );
  }
}
