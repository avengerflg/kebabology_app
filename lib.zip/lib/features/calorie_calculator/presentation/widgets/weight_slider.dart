// lib/features/calorie_calculator/presentation/widgets/weight_slider.dart

import 'package:flutter/material.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/utils/calculations.dart';

class WeightSlider extends StatelessWidget {
  final double weight;
  final ValueChanged<double> onChanged;
  final double minWeight;
  final double maxWeight;

  const WeightSlider({
    super.key,
    required this.weight,
    required this.onChanged,
    this.minWeight = 250,
    this.maxWeight = 999,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppConstants.cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppConstants.borderColor.withOpacity(0.5),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 4,
                    height: 20,
                    decoration: BoxDecoration(
                      color: AppConstants.accentColor,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Kebab Weight',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: AppConstants.accentColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: AppConstants.accentColor.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Text(
                  Calculations.formatWeight(weight),
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: AppConstants.accentColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            Calculations.getWeightDifference(weight),
            style: theme.textTheme.bodySmall?.copyWith(
              color: AppConstants.secondaryTextColor,
            ),
          ),
          const SizedBox(height: 20),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 6,
              thumbShape: const RoundSliderThumbShape(
                enabledThumbRadius: 12,
                elevation: 4,
              ),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 24),
              activeTickMarkColor: Colors.transparent,
              inactiveTickMarkColor: Colors.transparent,
            ),
            child: Slider(
              value: weight,
              min: minWeight,
              max: maxWeight,
              divisions: ((maxWeight - minWeight) / 10).round(),
              onChanged: onChanged,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${minWeight.round()}g',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: AppConstants.secondaryTextColor,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppConstants.surfaceColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Standard: ${AppConstants.standardKebabWeight.round()}g',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: AppConstants.secondaryTextColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Text(
                '${maxWeight.round()}g',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: AppConstants.secondaryTextColor,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
