// lib/features/calorie_calculator/data/models/nutrition_data.dart

import 'kebab_component.dart';

class NutritionData {
  // BREAD COMPONENTS - From Excel data
  static const List<KebabComponent> breadOptions = [
    KebabComponent(
      id: 'greek',
      name: 'Greek',
      type: ComponentType.bread,
      calories: 248.3,
      protein: 8.0,
      carbohydrates: 48.8,
      defaultGrams: 98,
    ),
    KebabComponent(
      id: 'lebanese',
      name: 'Lebanese',
      type: ComponentType.bread,
      calories: 237.1,
      protein: 7.6,
      carbohydrates: 46.5,
      defaultGrams: 80,
    ),
    KebabComponent(
      id: 'turkish',
      name: 'Turkish',
      type: ComponentType.bread,
      calories: 260.5,
      protein: 9.3,
      carbohydrates: 46.3,
      defaultGrams: 100,
    ),
  ];

  // MEAT COMPONENTS - From Excel data
  static const List<KebabComponent> meatOptions = [
    KebabComponent(
      id: 'lamb',
      name: 'Lamb',
      type: ComponentType.meat,
      calories: 560.5,
      protein: 31.9,
      carbohydrates: 20.0,
      defaultGrams: 175,
    ),
    KebabComponent(
      id: 'chicken',
      name: 'Chicken',
      type: ComponentType.meat,
      calories: 375.8,
      protein: 48.1,
      carbohydrates: 5.6,
      defaultGrams: 170,
    ),
    KebabComponent(
      id: 'beef',
      name: 'Beef',
      type: ComponentType.meat,
      calories: 567.6,
      protein: 55.2,
      carbohydrates: 1.7,
      defaultGrams: 187,
    ),
  ];

  // SALAD COMPONENTS - From Excel data
  static const List<KebabComponent> saladOptions = [
    KebabComponent(
      id: 'lettuce',
      name: 'Lettuce',
      type: ComponentType.salad,
      calories: 9.8,
      protein: 0.7,
      carbohydrates: 0.9,
      defaultGrams: 50,
    ),
    KebabComponent(
      id: 'tomato',
      name: 'Tomato',
      type: ComponentType.salad,
      calories: 8.8,
      protein: 0.5,
      carbohydrates: 1.1,
      defaultGrams: 47,
    ),
    KebabComponent(
      id: 'onion',
      name: 'Fresh Onions',
      type: ComponentType.salad,
      calories: 13.1,
      protein: 0.7,
      carbohydrates: 1.9,
      defaultGrams: 40,
    ),
    KebabComponent(
      id: 'tabouli',
      name: 'Parsely Tabouli',
      type: ComponentType.salad,
      calories: 7.6,
      protein: 0.7,
      carbohydrates: 0.2,
      defaultGrams: 31,
    ),
    KebabComponent(
      id: 'cheese',
      name: 'Cheese (Tasty Cheddar)',
      type: ComponentType.salad,
      calories: 218.3,
      protein: 13.5,
      carbohydrates: 0.3,
      defaultGrams: 55,
    ),
  ];

  // SAUCE COMPONENTS - From Excel data
  static const List<KebabComponent> sauceOptions = [
    KebabComponent(
      id: 'chilli',
      name: 'Chilli',
      type: ComponentType.sauce,
      calories: 19.0,
      protein: 0.4,
      carbohydrates: 3.1,
      defaultGrams: 21,
    ),
    KebabComponent(
      id: 'bbq',
      name: 'BBQ',
      type: ComponentType.sauce,
      calories: 58.9,
      protein: 0.1,
      carbohydrates: 14.1,
      defaultGrams: 28,
    ),
    KebabComponent(
      id: 'garlic',
      name: 'Garlic',
      type: ComponentType.sauce,
      calories: 26.7,
      protein: 1.4,
      carbohydrates: 2.2,
      defaultGrams: 27,
    ),
    KebabComponent(
      id: 'hummus',
      name: 'Hummus',
      type: ComponentType.sauce,
      calories: 75.3,
      protein: 2.4,
      carbohydrates: 2.8,
      defaultGrams: 30,
    ),
    KebabComponent(
      id: 'tomato_sauce',
      name: 'Tomato',
      type: ComponentType.sauce,
      calories: 33.7,
      protein: 0.4,
      carbohydrates: 7.5,
      defaultGrams: 30,
    ),
    KebabComponent(
      id: 'mayonnaise',
      name: 'Mayonnaise',
      type: ComponentType.sauce,
      calories: 188.7,
      protein: 0.5,
      carbohydrates: 0.4,
      defaultGrams: 27,
    ),
    KebabComponent(
      id: 'sweet_chilli',
      name: 'Sweet Chilli',
      type: ComponentType.sauce,
      calories: 59.9,
      protein: 0.0,
      carbohydrates: 14.6,
      defaultGrams: 24,
    ),
    KebabComponent(
      id: 'sour_cream',
      name: 'Sour Cream',
      type: ComponentType.sauce,
      calories: 87.2,
      protein: 0.5,
      carbohydrates: 0.9,
      defaultGrams: 25,
    ),
  ];

  static KebabComponent? getComponentById(String id) {
    final allComponents = [
      ...breadOptions,
      ...meatOptions,
      ...saladOptions,
      ...sauceOptions,
    ];

    try {
      return allComponents.firstWhere((component) => component.id == id);
    } catch (e) {
      return null;
    }
  }
}
