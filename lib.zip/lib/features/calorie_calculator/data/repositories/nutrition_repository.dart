// lib/features/calorie_calculator/data/repositories/nutrition_repository.dart

import '../models/kebab_component.dart';

class NutritionRepository {
  // Fixed percentage allocations for a standard kebab
  static const double breadPercentage = 0.2178;  // 21.78%
  static const double meatPercentage = 0.4156;   // 41.56%
  static const double saladPercentage = 0.3044;  // 30.44%
  static const double saucePercentage = 0.0622;  // 6.22%

  // Calculate total nutrition for all selected components
  Map<String, double> calculateTotalNutrition({
    required String? selectedBread,
    required List<String> selectedMeats,
    required List<String> selectedSalads,
    required List<String> selectedSauces,
    required double kebabWeight,
    required List<KebabComponent> allComponents,
  }) {
    // Initialize totals
    final totals = {
      'calories': 0.0,
      'protein': 0.0,
      'carbohydrates': 0.0,
      'fat': 0.0,
      'fiber': 0.0,
      'sugar': 0.0,
      'sodium': 0.0,
    };

    // Calculate actual weights for each component type
    final breadWeight = kebabWeight * breadPercentage;
    final sauceWeight = kebabWeight * saucePercentage;
    
    // Adjust meat and salad percentages based on salad selection
    final meatWeight = selectedSalads.isEmpty 
        ? kebabWeight * (meatPercentage + saladPercentage)  // 72% if no salad
        : kebabWeight * meatPercentage;  // 41.56% if salad selected
    
    final saladWeight = selectedSalads.isEmpty 
        ? 0.0 
        : kebabWeight * saladPercentage;

    // Calculate bread nutrition
    if (selectedBread != null) {
      final bread = allComponents.firstWhere((c) => c.id == selectedBread);
      final breadRatio = breadWeight / bread.defaultGrams;
      _addNutrition(totals, bread, breadRatio);
    }

    // Calculate meat nutrition (split equally among selected meats)
    if (selectedMeats.isNotEmpty) {
      final weightPerMeat = meatWeight / selectedMeats.length;
      for (final meatId in selectedMeats) {
        final meat = allComponents.firstWhere((c) => c.id == meatId);
        final meatRatio = weightPerMeat / meat.defaultGrams;
        _addNutrition(totals, meat, meatRatio);
      }
    }

    // Calculate salad nutrition (split equally among selected salads)
    if (selectedSalads.isNotEmpty) {
      final weightPerSalad = saladWeight / selectedSalads.length;
      for (final saladId in selectedSalads) {
        final salad = allComponents.firstWhere((c) => c.id == saladId);
        final saladRatio = weightPerSalad / salad.defaultGrams;
        _addNutrition(totals, salad, saladRatio);
      }
    }

    // Calculate sauce nutrition (split equally among selected sauces)
    if (selectedSauces.isNotEmpty) {
      final weightPerSauce = sauceWeight / selectedSauces.length;
      for (final sauceId in selectedSauces) {
        final sauce = allComponents.firstWhere((c) => c.id == sauceId);
        final sauceRatio = weightPerSauce / sauce.defaultGrams;
        _addNutrition(totals, sauce, sauceRatio);
      }
    }

    return totals;
  }

  // Helper method to add nutrition values
  void _addNutrition(Map<String, double> totals, KebabComponent component, double ratio) {
    totals['calories'] = (totals['calories'] ?? 0) + (component.calories * ratio);
    totals['protein'] = (totals['protein'] ?? 0) + (component.protein * ratio);
    totals['carbohydrates'] = (totals['carbohydrates'] ?? 0) + (component.carbohydrates * ratio);
    totals['fat'] = (totals['fat'] ?? 0) + (component.fat * ratio);
    totals['fiber'] = (totals['fiber'] ?? 0) + (component.fiber * ratio);
    totals['sugar'] = (totals['sugar'] ?? 0) + (component.sugar * ratio);
    totals['sodium'] = (totals['sodium'] ?? 0) + (component.sodium * ratio);
  }

  // Calculate nutrition breakdown by component type
  Map<ComponentType, Map<String, double>> calculateNutritionByType({
    required String? selectedBread,
    required List<String> selectedMeats,
    required List<String> selectedSalads,
    required List<String> selectedSauces,
    required double kebabWeight,
    required List<KebabComponent> allComponents,
  }) {
    final breakdown = <ComponentType, Map<String, double>>{
      ComponentType.bread: initializeNutritionMap(),
      ComponentType.meat: initializeNutritionMap(),
      ComponentType.salad: initializeNutritionMap(),
      ComponentType.sauce: initializeNutritionMap(),
    };

    // Calculate actual weights for each component type
    final breadWeight = kebabWeight * breadPercentage;
    final sauceWeight = kebabWeight * saucePercentage;
    final meatWeight = selectedSalads.isEmpty 
        ? kebabWeight * (meatPercentage + saladPercentage)
        : kebabWeight * meatPercentage;
    final saladWeight = selectedSalads.isEmpty 
        ? 0.0 
        : kebabWeight * saladPercentage;

    // Calculate bread nutrition
    if (selectedBread != null) {
      final bread = allComponents.firstWhere((c) => c.id == selectedBread);
      final breadRatio = breadWeight / bread.defaultGrams;
      _addNutrition(breakdown[ComponentType.bread]!, bread, breadRatio);
    }

    // Calculate meat nutrition
    if (selectedMeats.isNotEmpty) {
      final weightPerMeat = meatWeight / selectedMeats.length;
      for (final meatId in selectedMeats) {
        final meat = allComponents.firstWhere((c) => c.id == meatId);
        final meatRatio = weightPerMeat / meat.defaultGrams;
        _addNutrition(breakdown[ComponentType.meat]!, meat, meatRatio);
      }
    }

    // Calculate salad nutrition
    if (selectedSalads.isNotEmpty) {
      final weightPerSalad = saladWeight / selectedSalads.length;
      for (final saladId in selectedSalads) {
        final salad = allComponents.firstWhere((c) => c.id == saladId);
        final saladRatio = weightPerSalad / salad.defaultGrams;
        _addNutrition(breakdown[ComponentType.salad]!, salad, saladRatio);
      }
    }

    // Calculate sauce nutrition
    if (selectedSauces.isNotEmpty) {
      final weightPerSauce = sauceWeight / selectedSauces.length;
      for (final sauceId in selectedSauces) {
        final sauce = allComponents.firstWhere((c) => c.id == sauceId);
        final sauceRatio = weightPerSauce / sauce.defaultGrams;
        _addNutrition(breakdown[ComponentType.sauce]!, sauce, sauceRatio);
      }
    }

    return breakdown;
  }

  Map<String, double> initializeNutritionMap() {
    return {
      'calories': 0.0,
      'protein': 0.0,
      'carbohydrates': 0.0,
      'fat': 0.0,
      'fiber': 0.0,
      'sugar': 0.0,
      'sodium': 0.0,
    };
  }

  // Get the actual weight allocations for display
  Map<String, double> getWeightAllocations({
    required List<String> selectedSalads,
    required double kebabWeight,
  }) {
    return {
      'bread': kebabWeight * breadPercentage,
      'meat': selectedSalads.isEmpty 
          ? kebabWeight * (meatPercentage + saladPercentage)
          : kebabWeight * meatPercentage,
      'salad': selectedSalads.isEmpty 
          ? 0.0 
          : kebabWeight * saladPercentage,
      'sauce': kebabWeight * saucePercentage,
    };
  }

  // Format nutrition value for display
  String formatNutritionValue(double value, String nutrient) {
    if (nutrient == 'calories') {
      return value.round().toString();
    }
    // For other nutrients, show one decimal place if needed
    return value.toStringAsFixed(value.truncate() == value ? 0 : 1);
  }
}